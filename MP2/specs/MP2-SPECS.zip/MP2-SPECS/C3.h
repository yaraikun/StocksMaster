/* 

    C3.h
    Header file for Challenge #3
    
    You are NOT allowed to change the contents of this file.

*/

// MAX is the maximum number of rows of SHD values (for AC.TXT the actual number of rows is 1216)
#define MAX (1225)

// StrDate alias is to be used with a string that represents a date
typedef char StrDate[11]; 

